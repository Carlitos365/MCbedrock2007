<?php
require "config/conex.php";
$habitacion=$_POST["habitaciones"];
$sql="INSERT INTO habitaciones(valor) VALUES(".$habitacion.")";
$sql = "UPDATE habitaciones
SET
estado=1
WHERE
id= ".$habitacion."";
if($dbh-> query ($sql)){

    echo"actualizacion correcta";
}else{
    echo "error en la actualizacion";
}







?>