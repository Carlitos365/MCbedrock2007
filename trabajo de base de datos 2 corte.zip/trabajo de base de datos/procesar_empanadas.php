<?php

require "config/conex.php"; 

$cantidad= $_POST ["cantidad"];
$total = 1500 * $cantidad;


$sql = "INSERT INTO ventas_empanadas (venta) VALUES (".$total.")";

if($dbh->query($sql)){
    print "compra exitosa". $total;

}else{

    print "error en la compra";
}

?>