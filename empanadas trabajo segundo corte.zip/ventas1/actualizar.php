<?php

require "config/conex.php";


$cod = $_POST["cod"];
$nueva_cantidad = $_POST["cantidad2"];
$nuevo_valor= $_POST["nuevo_valor"];
$total2= ($nueva_cantidad*$nuevo_valor);

if($nuevo_valor> 1500 or $nuevo_valor<=0 or $nueva_cantidad<=0 or $cod <=0 or $cod>12 ){

    print "error en la venta (valor no adecuado)";
    
    
    
    
    
    }else{

$sql = "UPDATE ventas1 

SET cantidad='$nueva_cantidad',valor='$nuevo_valor',total='$total2' 

WHERE id = $cod";

if($dbh->query($sql)){

        print "exito en la actualizacion";

}else {

    print"error";
}
    }




?>

<!DOCTYPE html>
<html>
<a href="index.html" style="text-decoration:none;">    
<button style="background-color:yellow;">Regresar al inicio</button>
</a>

</html>