<?php

require "config/conex.php";


$cantidad = $_POST["cantidad"];
$valor= $_POST["valor"];
$total= ($cantidad*$valor);

if($valor > 1500 or $valor<=0){

print "error en la venta (valor no adecuado)";





}else{

$SQL = "INSERT INTO ventas1(cantidad, valor, total) 
VALUES ('$cantidad', '$valor', '$total')";


if($dbh->query($SQL)){

        print "Venta exitosa";

}else {


    print "error en la venta";
}
}
 



?>


<!DOCTYPE html>
<html>
<a href="index.html" style="text-decoration:none;">    
<button style="background-color:yellow;">Regresar al inicio</button>
</a>

</html>