<?php

require "config/conex.php";


$monto = $_POST["valor"];


$sql = "UPDATE usuarios

SET saldo = saldo + ".$monto."

WHERE id = 13";


if($dbh->query($sql)){

        print "transferencia exitosa";

}else {

    print"error al transferir";
}






?>