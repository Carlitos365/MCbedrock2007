<?php

//require//

require "config/conex.php";

$recargas= $_POST["valor"];




$sql = "UPDATE usuarios

SET saldo= saldo + ".$recargas." 

WHERE id=1";


if($dbh->query($sql)){

    print "Recarga exitosa";
}else{


    print "error en la recarga";
}





?>