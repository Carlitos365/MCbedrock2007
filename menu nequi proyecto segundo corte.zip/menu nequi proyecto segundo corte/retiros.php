<?php

require "config/conex.php";


$retiro = $_POST["retirar"];


$sql = "UPDATE usuarios

SET saldo = saldo - ".$retiro." WHERE id = 1";




if($dbh->query($sql)){

    print "Retiro exitoso";

}else{


    print "error en el retiro";
}






?>