<?php

//hacer el require//
require "config/conex.php";


//capturar variables //

$bebidas = $_POST["tipo_bebida"];
$cantidad= $_POST["cantidad"];
$descuento= $_POST["descuento"];
$total=0;
$total = $bebidas * $cantidad;


$sql= "INSERT INTO ventas_colibron( tipo_de_bebida, cantidad, aplica_descuento, total_venta) VALUES ('$bebidas','$cantidad','$descuento','$total')";


if($dbh->query($sql)){

        print "venta exitosa";

}else {


    print "Error en la venta";
}






?>