<?php

require "config/conex.php";



$cod = $_POST["cod"];



$descuento = $_POST["descuento"];


$sql = "UPDATE ventas_colibron 

SET aplica_descuento='$descuento' 

WHERE id = $cod";


if ($dbh ->query($sql)){


    print "datos actualizados";
}else{


    print "error en la actualizacion";
}







?>
